import sys
import xbmcplugin
import xbmcgui

__handle__ = int(sys.argv[1])

def show_menu():
    li = xbmcgui.ListItem(label="Test Channel - Click Me")
    li.setProperty('IsPlayable', 'true')
    url = f"{sys.argv[0]}?action=play"
    xbmcplugin.addDirectoryItem(__handle__, url, li, False)
    xbmcplugin.endOfDirectory(__handle__)

def play():
    # Using a known working test stream
    test_url = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
    li = xbmcgui.ListItem(path=test_url)
    li.setProperty('inputstream', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    xbmcplugin.setResolvedUrl(__handle__, True, li)

if len(sys.argv) > 2 and 'action=play' in sys.argv[2]:
    play()
else:
    show_menu()
