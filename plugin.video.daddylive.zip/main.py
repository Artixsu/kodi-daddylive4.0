import sys
import xbmc
import xbmcplugin
import xbmcgui
from urllib.parse import parse_qsl
import json
import re
import requests

# Using the original DaddyLive m3u8 URL
M3U8_URL = "https://raw.githubusercontent.com/nightah/daddylive/refs/heads/main/daddylive-channels-tivimate.m3u8"

__handle__ = int(sys.argv[1])

def log(msg):
    xbmc.log(f"[DaddyLive] {msg}", xbmc.LOGINFO)

def parse_m3u8(content):
    channels = []
    lines = content.strip().split('\n')
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        if line.startswith('#EXTINF:'):
            # Get channel name
            if ',' in line:
                name = line.split(',')[-1].strip()
            else:
                name = "Unknown"
            
            # Get group
            group_match = re.search(r'group-title="([^"]+)"', line)
            group = group_match.group(1) if group_match else "Uncategorized"
            
            # Get logo
            logo_match = re.search(r'tvg-logo="([^"]+)"', line)
            logo = logo_match.group(1) if logo_match else ""
            
            # Get URL from next line
            url = None
            for j in range(i+1, len(lines)):
                next_line = lines[j].strip()
                if next_line and not next_line.startswith('#'):
                    url = next_line.split('|')[0]
                    break
            
            if url:
                channels.append({
                    'name': name,
                    'group': group,
                    'url': url,
                    'logo': logo
                })
    
    return channels

def get_channels():
    try:
        resp = requests.get(M3U8_URL, timeout=15)
        if resp.status_code == 200:
            return parse_m3u8(resp.text)
    except Exception as e:
        log(f"Error: {e}")
    return []

def show_menu():
    channels = get_channels()
    
    if not channels:
        xbmcgui.Dialog().ok("DaddyLive", "Failed to load channels")
        return
    
    # Get unique groups
    groups = {}
    for ch in channels:
        if ch['group'] not in groups:
            groups[ch['group']] = []
        groups[ch['group']].append(ch)
    
    listing = []
    for group in sorted(groups.keys()):
        li = xbmcgui.ListItem(label=group)
        url = f"{sys.argv[0]}?action=channels&group={group}"
        listing.append((url, li, True))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def show_channels(group_name):
    channels = get_channels()
    group_channels = [ch for ch in channels if ch['group'] == group_name]
    
    listing = []
    for ch in group_channels:
        li = xbmcgui.ListItem(label=ch['name'])
        li.setProperty('IsPlayable', 'true')
        li.setInfo('video', {'title': ch['name']})
        
        if ch.get('logo'):
            li.setArt({'thumb': ch['logo']})
        
        data = json.dumps({'name': ch['name'], 'url': ch['url']})
        url = f"{sys.argv[0]}?action=play&data={data}"
        listing.append((url, li, False))
    
    xbmcplugin.addDirectoryItems(__handle__, listing, len(listing))
    xbmcplugin.endOfDirectory(__handle__)

def play(data):
    try:
        ch = json.loads(data)
        url = ch['url']
        name = ch.get('name', 'Stream')
        
        li = xbmcgui.ListItem(path=url)
        li.setInfo('video', {'title': name})
        
        if '.m3u8' in url.lower():
            li.setProperty('inputstream', 'inputstream.adaptive')
            li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        
        xbmcplugin.setResolvedUrl(__handle__, True, li)
    except:
        pass

def router():
    params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action', 'menu')
    
    if action == 'menu':
        show_menu()
    elif action == 'channels':
        show_channels(params.get('group', ''))
    elif action == 'play':
        play(params.get('data', '{}'))

if __name__ == '__main__':
    router()
